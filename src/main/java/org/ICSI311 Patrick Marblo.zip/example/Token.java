package org.example;

public class Token {

    enum TokenType {
        WORD,
        NUMBER,
        ENDOFLINE;
    }

    private TokenType tokenType;
    private String value;

    /**
     * Instantiates a Token to be used in lexing.
     * @param tokenType the type of token
     * @param value the value of the token
     */
    public Token(TokenType tokenType, String value){
        this.tokenType = tokenType;
        this.value = value;
    }

    /**
     * The type of token.
     * @return the type of token
     */
    public TokenType getTokenType(){
        return this.tokenType;
    }

    /**
     * The value of the token
     * @return value of token
     */
    public String getValue(){
        return this.value;
    }

    public String toString(){
        return getTokenType().name() + "(" + getValue() + ")";
    }

}
