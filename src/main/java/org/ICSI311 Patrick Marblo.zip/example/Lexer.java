package org.example;

import java.util.ArrayList;
import java.util.List;

public class Lexer {

    List<Token> tokenList = new ArrayList<>();
    private String input;
    private int index = 0;

    /**
     * Instantiates a Lexer.
     * @param input the line of text to lex
     */
    public Lexer(String input){
        this.input = input;
    }

    /**
     * State of the lexer through lexical analysis. 
     */
    enum LexState {
        NONE,
        WORD,
        NUMBER
    }

    public void lex() throws LexerException {
        LexState currentState = LexState.NONE;
        // Loop through each character
        while(index < input.length()) {
            char c = input.charAt(index);
            switch (currentState) {
                default:
                case NONE:
                    // We're at the beginning of a token.
                    if(Character.isLetter(c))
                        currentState = LexState.WORD;
                    else if(Character.isDigit(c))
                        currentState = LexState.NUMBER;
                    else
                        index++;
                    break;
                case WORD:
                    // Words can contain both numbers and letters.
                    if(Character.isLetterOrDigit(c)) {
                        int start = index;

                        String value = input.substring(start, index);
                        addToken(new Token(Token.TokenType.WORD, readWord()));
                        currentState = LexState.NONE;
                    }

                    break;
                case NUMBER:
                    if(Character.isDigit(c)){
                        int start = index;

                        String value = input.substring(start, index);
                        addToken(new Token(Token.TokenType.NUMBER, readNumber()));

                        currentState = LexState.NONE;

                    }

                    break;

            }
        }
    }

    /**
     * Add a token to the list of tokens lexed.
     * @param token the token to add
     */
    public void addToken(Token token){
        tokenList.add(token);
        System.out.println("New token: " + token.toString());
    }

    /**
     * Helper method to read the rest of a word, given it is alphanumeric.
     * @return the word that was read
     */
    private String readWord() {
        int start = index;
        while (index < input.length() && isAlphanumeric(input.charAt(index))) {
            index++;
        }
        return input.substring(start, index);
    }

    /**
     * Helper method to read digits.
     * @return the number read from digits
     * @throws LexerException if the digit parsed is not valid
     */
    private String readNumber() throws LexerException {
        int start = index;
        while (index < input.length() && (Character.isDigit(input.charAt(index)) || input.charAt(index) == '.')) {
            index++;
        }
        String number = input.substring(start, index);
        try {
            Double.parseDouble(number);
        } catch (NumberFormatException e) {
            throw new LexerException("Invalid number format: " + number);
        }
        return number;
    }
    /**
     * Whether the character is alphanumeric or not.
     * @param c the character to analyze
     * @return
     */
    private boolean isAlphanumeric(char c){
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || Character.isDigit(c);
    }

    /**
     * LexerException class to handle any exceptions during lexical analysis.
     */
    public static class LexerException extends Exception {
        public LexerException(String message){
            super(message);
        }
    }
}
